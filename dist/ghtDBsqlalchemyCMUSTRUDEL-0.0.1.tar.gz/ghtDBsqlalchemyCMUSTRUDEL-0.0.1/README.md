# ghtDB-sqlalchemy

This is a simple package with SQLAlchemy mappings for [GHTorrent](http://ghtorrent.org).
